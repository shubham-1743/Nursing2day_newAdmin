<?php
    $controller = DzHelper::controller();
    $page = $action = DzHelper::action();
    $action = $controller.'_'.$action;
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Title -->
    <title><?php echo e(config('dz.name')); ?> | <?php echo $__env->yieldContent('title', $page_title ?? ''); ?></title>

	<!-- Meta -->
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="robots" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meta name="description" content="<?php echo $__env->yieldContent('page_description', $page_description ?? ''); ?>">
	<meta property="og:title" content="W3crm:Customer Relationship Management Admin Bootstrap 5 & Laravel Template">
	<meta property="og:description" content="<?php echo e(config('dz.name')); ?> | <?php echo $__env->yieldContent('title', $page_title ?? ''); ?>">
	<meta property="og:image" content="https://w3crm.dexignzone.com/laravel/social-image.png">
	<meta name="format-detection" content="telephone=no">
	<!-- Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicons Icon -->
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/images/favicon.png')); ?>">

    <link href="<?php echo e(asset('public/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylesheet">

</head>

<body class="vh-100">
    <div class="authincation h-100">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

<!--**********************************
	Scripts
***********************************-->
    <!-- Required vendors -->
    <?php if(!empty(config('dz.public.global.js.top'))): ?>
    <?php $__currentLoopData = config('dz.public.global.js.top'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $script): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e(asset('public/'.$script)); ?>" type="text/javascript"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(!empty(config('dz.public.pagelevel.js.'.$action))): ?>
    <?php $__currentLoopData = config('dz.public.pagelevel.js.'.$action); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $script): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e(asset('public/'.$script)); ?>" type="text/javascript"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(!empty(config('dz.public.global.js.bottom'))): ?>
    <?php $__currentLoopData = config('dz.public.global.js.bottom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $script): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e(asset('public/'.$script)); ?>" type="text/javascript"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/brosistechnology/examfighter.brosistechnology.in/resources/views/admin-main/layouts/fullwidth.blade.php ENDPATH**/ ?>