
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li><h5 class="bc-title">MANAGE VOYAGE</h5></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/voyages/create')); ?>">+ Add voyage</a>
</div>
<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header py-3 d-sm-flex d-block">
                    <h4 class="card-title mb-2">voyage</h4>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive active-projects style-1">
                        <table id="empoloyees-tblwrapper" class="table">
                            <thead>
                                <tr>
                                    <th>Voyage Code</th>
                                    <th>Voyage Number</th>
                                    <th>M Vessel Name</th>
                                    <th>Arrival Date</th>
                                    <th>IGM Number</th>
                                    <th>IGM Date</th>
                                    <th>Shipping Line</th>
                                    <th>F Voyage No</th>
                                    <th>F Vessel Name</th>
                                    <th>Mumbai IGM No</th>
                                    <th>Mumbai IGM Date</th>
                                    <th>Overseas Agent</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $MasterVoyages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MasterVoyage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($MasterVoyage->voyage_code); ?></td>
                                        <td><?php echo e($MasterVoyage->voyage_number); ?></td>
                                        <td><?php echo e($MasterVoyage->m_vessel_id); ?></td>
                                        <td><?php echo e($MasterVoyage->arrival_date); ?></td>
                                        <td><?php echo e($MasterVoyage->igm_number); ?></td>
                                        <td><?php echo e($MasterVoyage->igm_date); ?></td>
                                        <td><?php echo e($MasterVoyage->shipping_line_id); ?></td>
                                        <td><?php echo e($MasterVoyage->f_voyage_no); ?></td>
                                        <td><?php echo e($MasterVoyage->f_vessel_id); ?></td>
                                        <td><?php echo e($MasterVoyage->mumbai_igm_no); ?></td>
                                        <td><?php echo e($MasterVoyage->mumbai_igm_date); ?></td>
                                        <td><?php echo e($MasterVoyage->overseas_agent_id); ?></td>
                                        <td>
                                            <?php if($MasterVoyage->status == 1): ?>
                                                <span class="badge badge-success light border-0">Active</span>                                                
                                            <?php else: ?>
                                                <span class="badge badge-danger light border-0">Deactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="badge badge-info light border-0" href="<?php echo e(url('admin/voyages/'.$MasterVoyage->id.'/edit')); ?>">Edit</a>
                                            <a class="badge badge-danger light border-0 delete-voyage" href="javascript:void(0);" data-id="<?php echo e($MasterVoyage->id); ?>">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($MasterVoyages->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on('click', '.delete-voyage', function(e) {
            e.preventDefault();
            if (!confirm('Are you sure you want to delete this voyage?')) return;

            const voyageId = $(this).data('id');

            $.ajax({
                url: '/admin/voyages/' + voyageId,
                type: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    alert('voyage deleted successfully.');
                    location.reload();
                },
                error: function(xhr) {
                    alert('Failed to delete voyage.');
                    console.log(xhr.responseText);
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brosistechnology/bamryashipping.brosistechnology.in/resources/views/admin-main/admin/voyage/index.blade.php ENDPATH**/ ?>