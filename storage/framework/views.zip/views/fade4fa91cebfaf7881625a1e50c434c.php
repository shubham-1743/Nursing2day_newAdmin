<div class="footer">
    <div class="copyright">
       <p>Copyright © Developed by <a href="https://dexignzone.com/" target="_blank">DexignZone</a> 2023</p>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/elements/footer.blade.php ENDPATH**/ ?>