
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Add New QuestionTypes</a></li>
        </ol>
        <a class="text-primary fs-13" href="<?php echo e(url('admin/QuestionTypes')); ?>">+ Back QuestionTypes</a>
    </div>
    <div class="container-fluid p-2">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Essay Type Questions -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Essay Questions:</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="essay_questions">
                                        </div>
                                    </div>
                        
                                    <!-- Long Answer Questions -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Long Answer Questions:</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="long_answer_questions">
                                        </div>
                                    </div>
                        
                                    <!-- Short Answer Questions -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Short Answer Questions:</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="short_answer_questions">
                                        </div>
                                    </div>
                        
                                    <!-- Very Short Answer Questions -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Very Short Answer:</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="very_short_answer_questions">
                                        </div>
                                    </div>
                        
                                    <!-- Fill in the Blanks -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Fill in the Blanks:</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="fill_in_the_blanks">
                                        </div>
                                    </div>
                        
                                    <!-- Multiple Choice Questions -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">MCQ Questions:</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="mcq_questions">
                                        </div>
                                    </div>
                        
                                    <!-- Marks per Question -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Marks (Each Type):</label>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" name="marks_per_question">
                                        </div>
                                    </div>
                        
                                    <!-- Negative Marking -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Negative Marking:</label>
                                        <div class="col-sm-6">
                                            <input type="number" step="0.01" class="form-control" name="negative_marking">
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#smartwizard').smartWizard();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/questiontype/create.blade.php ENDPATH**/ ?>