
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">QuestionBnak</a></li>
        </ol>
        <a class="text-primary fs-13" href="<?php echo e(url('admin/QuestionBnak')); ?>"><- Go Back</a>
    </div>
    <div class="container-fluid p-2">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add New QuestionBnak</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Question Type -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Question Type:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="class">
                                        </div>
                                    </div>
                        
                                    <!-- Class -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Class:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="class">
                                        </div>
                                    </div>
                        
                                    <!-- Subject -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Subject:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="subject">
                                        </div>
                                    </div>
                        
                                    <!-- Chapter -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Chapter:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="chapter">
                                        </div>
                                    </div>
                        
                                    <!-- Topic -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Topic:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="topic">
                                        </div>
                                    </div>
                        
                                    <!-- Question Title -->
                                    <div class="mb-3 col-xl-6 col-xxl-12 row">
                                        <label class="col-sm-3 col-form-label">Question Title:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="question_title">
                                        </div>
                                    </div>
                        
                                    <!-- Answer -->
                                    <div class="mb-3 col-xl-6 col-xxl-12 row">
                                        <label class="col-sm-3 col-form-label">Answer:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="answer">
                                        </div>
                                    </div>
                        
                                    <!-- Options A to E (only for MCQ) -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Options </label>
                                        <div class="col-sm-7">
                                            <select class="form-control" name="options">
                                                <option value="A">A</option>
                                                <option value="B">B</option>
                                                <option value="C">C</option>
                                                <option value="D">D</option>
                                                <option value="E">E</option>
                                            </select>
                                        </div>
                                    </div>
                                   
                        
                                    <!-- Marks -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Marks:</label>
                                        <div class="col-sm-7">
                                            <input type="number" class="form-control" name="marks">
                                        </div>
                                    </div>
                                </div>
                        
                                <!-- Upload Options -->
                                <h4 class="mt-4">Upload Options</h4>
                                <hr>
                                <div class="row form-material">
                        
                                    <!-- Manual Entry Checkbox -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Manual Entry:</label>
                                        <div class="col-sm-6">
                                            <input type="checkbox" name="upload_option[]" value="manual">
                                        </div>
                                    </div>
                        
                                    <!-- Excel Upload -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">Excel Upload:</label>
                                        <div class="col-sm-6">
                                            <input type="file" name="excel_file" accept=".xlsx,.xls">
                                        </div>
                                    </div>
                        
                                    <!-- PDF/DOC Upload -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-6 col-form-label">PDF/DOC Upload:</label>
                                        <div class="col-sm-6">
                                            <input type="file" name="pdf_doc_file" accept=".pdf,.doc,.docx">
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <!-- Submit Button -->
                                <div class="col-4 mt-3">
                                    <button type="submit" class="btn btn-info">Save</button>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    

   
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#smartwizard').smartWizard();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/questionbank/create.blade.php ENDPATH**/ ?>