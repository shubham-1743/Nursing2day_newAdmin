
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">PaymentGateway</a></li>
        </ol>
        <a class="text-primary fs-13" href="<?php echo e(url('admin/PaymentGateway')); ?>"><- Go Back</a>
    </div>
    <div class="container-fluid p-2">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add New PaymentGateway</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                        
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Gateway Name -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Gateway Name:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="gateway_name">
                                        </div>
                                    </div>
                        
                                    <!-- API Key -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">API Key:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="api_key">
                                        </div>
                                    </div>
                        
                                    <!-- Token -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Token:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="token">
                                        </div>
                                    </div>
                        
                                    <!-- Status -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Status:</label>
                                        <div class="col-sm-7">
                                            <select class="form-control" name="status">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4 mt-3">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                        
                       


                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#smartwizard').smartWizard();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/paymentgateway/create.blade.php ENDPATH**/ ?>