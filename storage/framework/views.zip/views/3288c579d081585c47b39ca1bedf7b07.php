
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li><h5 class="bc-title">MANAGE Board of Education</h5></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/Boards/create')); ?>">+ Add Boards</a>
</div>
<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header py-3 d-sm-flex d-block">
                    <h4 class="card-title mb-2">Ports</h4>
                </div>
                <div class="card-header d-block pb-2">
                    <form class="row align-items-end" method="GET" action="">
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">Search By Port code</label>
                            <input type="text" placeholder="Enter code" class="form-control" name="port_code" id="port_code" value="<?php echo e(request('port_code')); ?>">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">search by port name</label>
                            <input type="text" placeholder="Enter Name" class="form-control" name="port_name" id="port_name" value="">
                        </div>

                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">search by EDI code</label>
                            <input type="text" placeholder="Enter edi code" class="form-control" name="edi_code" id="edi_code" value="">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">search by JNPT code </label>
                            <input type="text" placeholder="Enter jnpt code " class="form-control" name="jnpt_code " id="jnpt_code " value="">
                        </div>

                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">search by NSICT code</label>
                            <input type="text" placeholder="Enter Name" class="form-control" name="nsict_code" id="nsict_code" value="">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">search by GTI code</label>
                            <input type="text" placeholder="Enter Name" class="form-control" name="gti_code" id="gti_code" value="<?php echo e(request('gti_code')); ?>">
                        </div>

                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <button id="applyFilter" class="btn btn-primary" type="submit">Apply</button>
                            <a href="" class="btn btn-danger light ms-2" type="button">Reset</a>
                        </div>
                    </form>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive active-projects style-1">
                        <table id="empoloyees-tblwrapper" class="table">
                            <thead>
                                <tr>
                                    <th>Board Name </th>
                                    <th>Remark</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <a class="badge badge-info light border-0" href="<?php echo e(url('admin/Boards/edit/id')); ?>">Edit</a>
                                        <a class="badge badge-danger light border-0" href="#">Delete</a>
                                    </td>

                                </tr>
                               
                                
                            </tbody>
                        </table>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on('click', '.delete-port', function(e) {
            e.preventDefault();
            if (!confirm('Are you sure you want to delete this port record?')) return;

            const portId = $(this).data('id');

            $.ajax({
                url: '/admin/ports/' + portId,
                type: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    alert('Port Record deleted successfully.');
                    location.reload();
                },
                error: function(xhr) {
                    alert('Failed to delete port record.');
                    console.log(xhr.responseText);
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/boards/index.blade.php ENDPATH**/ ?>