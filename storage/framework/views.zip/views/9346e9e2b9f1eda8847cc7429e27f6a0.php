
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Papermanagement</a></li>
        </ol>
        <a class="text-primary fs-13" href="<?php echo e(url('admin/Papermanagement')); ?>"><- Go Back</a>
    </div>
    <div class="container-fluid p-2">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Add New Papermanagement</h4>
                    </div>
                   
                    <div class="card-body">
                        <form action="<?php echo e(url('admin/papers/store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Paper Name -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Paper Name:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="paper_name">
                                        </div>
                                    </div>
                        
                                    <!-- Class -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Class:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="class">
                                        </div>
                                    </div>
                        
                                    <!-- Subject -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Subject:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="subject">
                                        </div>
                                    </div>
                        
                                    <!-- Total Marks -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Total Marks:</label>
                                        <div class="col-sm-7">
                                            <input type="number" class="form-control" name="total_marks">
                                        </div>
                                    </div>
                        
                                    <!-- Total Questions -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Total Questions:</label>
                                        <div class="col-sm-7">
                                            <input type="number" class="form-control" name="total_questions">
                                        </div>
                                    </div>
                        
                                    <!-- Status -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 row">
                                        <label class="col-sm-5 col-form-label">Status:</label>
                                        <div class="col-sm-7">
                                            <select class="form-control" name="status">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4 mt-3">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

   
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#smartwizard').smartWizard();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/papermanagement/create.blade.php ENDPATH**/ ?>