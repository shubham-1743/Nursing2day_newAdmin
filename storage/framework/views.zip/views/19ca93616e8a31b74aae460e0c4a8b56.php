

<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Add New BL Type</a></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/bl-types')); ?>">+ Back BL Type</a>
</div>

<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12 col-xxl-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('bl-types.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div id="smartwizard" class="form-wizard order-create">
                            <div class="row form-material">

                                <div class="col-xl-3 col-xxl-12 col-md-6 mb-3">
                                    <label class="form-label">BL Description: <span class="text-danger">*</span></label>
                                    <input type="text" name="bl_description" class="form-control" value="<?php echo e(old('bl_description')); ?>">
                                    <?php $__errorArgs = ['bl_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-xxl-12 col-md-6 mb-3">
                                    <label class="form-label">Status: <span class="text-danger">*</span></label>
                                    <select name="status" class="form-control default-select wide">
                                        <option value="">Select Status</option>
                                        <option value="1" <?php echo e(old('status') == '1' ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e(old('status') == '0' ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>
                            <div class="col-4 mt-2">
                                <button type="submit" class="btn btn-info">Save</button>
                            </div>
                        </div>
                    </form>
                </div> <!-- card-body -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('#smartwizard').smartWizard();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brosistechnology/bamryashipping.brosistechnology.in/resources/views/admin-main/admin/bltype/create.blade.php ENDPATH**/ ?>