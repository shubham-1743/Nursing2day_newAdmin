
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li><h5 class="bc-title">MANAGE CONTAINER</h5></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/containers/create')); ?>">+ ADD CONTAINER</a>
</div>
<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header py-3 d-sm-flex d-block">
                    <h4 class="card-title mb-2">CONTAINER</h4>
                </div>
                <div class="card-header d-block pb-2">
                    <form class="row align-items-end" method="get" action="<?php echo e(route('containers.index')); ?>">
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">Search by container no.</label>
                            <input type="text" class="form-control" placeholder="search.." id="container_no" name="container_no" value="<?php echo e(request('container_no')); ?>">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">Search by size.</label>
                            <input type="text" class="form-control"  placeholder="search.." id="size" name="size" value="<?php echo e(request('size')); ?>">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">Search by container type</label>
                            <input type="text" class="form-control" placeholder="search.." id="category" name="category" value="<?php echo e(request('category')); ?>">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <button id="applyFilter" class="btn btn-primary" type="submit">Apply</button>
                            <a href="<?php echo e(route('containers.index')); ?>" id="resetFilter" class="btn btn-danger light ms-2">Reset</a>
                        </div>
                    </form>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive active-projects style-1">
                        <table id="empoloyees-tblwrapper" class="table">
                            <thead>
                                <tr>
                                    <th>Container No</th>
                                    <th>Container Size</th>
                                    <th>Container Type</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                        <td><?php echo e($container->container_no); ?></td>
                                        <td><?php echo e($container->size); ?></td>
                                        <td><?php echo e($container->category); ?></td>
                                        <td>
                                            <?php if($container->status == 1): ?>
                                                <span class="badge badge-success light border-0">Active</span>                                                
                                            <?php else: ?>
                                                <span class="badge badge-danger light border-0">Deactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="badge badge-info light border-0" href="<?php echo e(url('admin/containers/'.$container->id.'/edit')); ?>">Edit</a>
                                            <a class="badge badge-danger light border-0 delete-container" href="javascript:void(0);" data-id="<?php echo e($container->id); ?>">Delete</a>
                                        </td>
                                    </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($containers->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on('click', '.delete-container', function(e) {
            e.preventDefault();
            if (!confirm('Are you sure you want to delete this container?')) return;

            const containerId = $(this).data('id');

            $.ajax({
                url: '/admin/containers/' + containerId,
                type: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    alert('container deleted successfully.');
                    location.reload();
                },
                error: function(xhr) {
                    alert('Failed to delete container.');
                    console.log(xhr.responseText);
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brosistechnology/bamryashipping.brosistechnology.in/resources/views/admin-main/admin/container/index.blade.php ENDPATH**/ ?>