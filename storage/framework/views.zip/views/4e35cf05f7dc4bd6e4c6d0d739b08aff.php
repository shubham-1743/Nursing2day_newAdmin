
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Edit Bank Details</a></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/banks')); ?>">+ Back Bank Details</a>
</div>

<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12 col-xxl-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('banks.update', $bank->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div id="smartwizard" class="form-wizard order-create">
                            <input type="hidden" name="company_id" value="<?php echo e($bank->company_id); ?>">
                            <div class="row form-material">

                                <!-- Bank Name -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Bank Name:</label>
                                    <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="bank_name" value="<?php echo e(old('bank_name', $bank->bank_name)); ?>">
                                </div>

                                <!-- Beneficiary Name -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Beneficiary Name:</label>
                                    <span class="text-danger">*</span>
                                    <input type="text" class="form-control" name="beneficiary_name" value="<?php echo e(old('beneficiary_name', $bank->beneficiary_name)); ?>">
                                </div>

                                <!-- Branch Name -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Branch Name:</label>
                                    <input type="text" class="form-control" name="branch_name" value="<?php echo e(old('branch_name', $bank->branch_name)); ?>">
                                </div>

                                <!-- Account No -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Account No:</label>
                                    <input type="text" class="form-control" name="account_no" value="<?php echo e(old('account_no', $bank->account_no)); ?>">
                                </div>

                                <!-- IFSC Code -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">IFSC Code:</label>
                                    <input type="text" class="form-control" name="ifsc_code" value="<?php echo e(old('ifsc_code', $bank->ifsc_code)); ?>">
                                </div>

                                <!-- Account Type -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Account Type:</label>
                                    <select class="form-control" name="account_type">
                                        <option value="">Select</option>
                                        <option value="Saving Account" <?php echo e($bank->account_type == 'Saving Account' ? 'selected' : ''); ?>>Savings</option>
                                        <option value="Current Account" <?php echo e($bank->account_type == 'Current Account' ? 'selected' : ''); ?>>Current</option>
                                    </select>
                                </div>

                                <!-- Swift Code -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Swift Code:</label>
                                    <input type="text" class="form-control" name="swift_code" value="<?php echo e(old('swift_code', $bank->swift_code)); ?>">
                                </div>

                                <!-- GSTIN -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">GSTIN (Company):</label>
                                    <input type="text" class="form-control" name="gstin_no" value="<?php echo e(old('gstin_no', $bank->gstin_no_company)); ?>">
                                </div>

                                <!-- Company PAN -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Company PAN:</label>
                                    <input type="text" class="form-control" name="company_pan" value="<?php echo e(old('company_pan', $bank->company_pan)); ?>">
                                </div>

                                <!-- Company Name -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Company Name:</label>
                                    <input type="text" class="form-control" name="company_name" value="<?php echo e(old('company_name', $bank->company_name)); ?>">
                                </div>

                                <!-- Addresses -->
                                <?php for($i = 1; $i <= 3; $i++): ?>
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Branch Company Address <?php echo e($i); ?>:</label>
                                    <textarea class="form-control" name="address<?php echo e($i); ?>" rows="2"><?php echo e(old("address1", $bank->branch_company_address1)); ?></textarea>
                                </div>
                                <?php endfor; ?>

                                <!-- Contact No -->
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Contact No:</label>
                                    <input type="text" class="form-control" name="contact_no" value="<?php echo e(old('contact_no', $bank->contact_no)); ?>">
                                </div>

                                <!-- Notes 1 to 10 -->
                                <?php for($i = 1; $i <= 10; $i++): ?>
                                <div class="col-xl-3 col-xxl-6 col-md-6 mb-3">
                                    <label class="form-label">Notes <?php echo e($i); ?>:</label>
                                    <textarea class="form-control" name="notes<?php echo e($i); ?>" rows="2"><?php echo e(old("notes$i", $bank["notes$i"])); ?></textarea>
                                </div>
                                <?php endfor; ?>
                            </div>

                            <div class="col-4">
                                <button type="submit" class="btn btn-info">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#smartwizard').smartWizard();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brosistechnology/bamryashipping.brosistechnology.in/resources/views/admin-main/admin/bank/edit.blade.php ENDPATH**/ ?>