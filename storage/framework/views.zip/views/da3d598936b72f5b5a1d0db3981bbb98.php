
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Add New Paper</a></li>
        </ol>
        <a class="text-primary fs-13" href="<?php echo e(url('admin/Papers')); ?>">+ Back Role</a>
    </div>
    <div class="container-fluid p-2">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Paper Name -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Paper Name:</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="paper_name">
                                        </div>
                                    </div>
                        
                                    <!-- Class -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Class:</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="class">
                                        </div>
                                    </div>
                        
                                    <!-- Payment Flow -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Payment Flow:</label>
                                        <div class="col-sm-8">
                                            <select class="form-control" name="payment_flow">
                                                <option value="online">Online</option>
                                                <option value="wallet">Wallet</option>
                                                <option value="cash">Cash</option>
                                            </select>
                                        </div>
                                    </div>
                        
                                    <!-- Download Quantity -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Download Quantity:</label>
                                        <div class="col-sm-8">
                                            <input type="number" class="form-control" name="download_quantity">
                                        </div>
                                    </div>
                        
                                    <!-- Net Payment -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Net Payment:</label>
                                        <div class="col-sm-8">
                                            <input type="number" step="0.01" class="form-control" name="net_payment">
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#smartwizard').smartWizard();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/paperhistory/create.blade.php ENDPATH**/ ?>