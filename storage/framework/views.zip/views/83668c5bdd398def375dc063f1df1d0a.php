
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="#">Notificatins</a></li>
        </ol>
        <a href="<?php echo e(url('admin/Notificatins')); ?>" class="text-primary"><- Go Back</a>
    </div>
    <div class="container-fluid p-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit Notificatins</h4>
                    </div><br>
                    
                    <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                        
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Notification Title -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Notification Title:</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" name="notification_title">
                                        </div>
                                    </div>
                        
                                    <!-- Remark / Description -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Remark / Description:</label>
                                        <div class="col-sm-7">
                                            <textarea class="form-control" name="description" rows="2"></textarea>
                                        </div>
                                    </div>
                        
                                    <!-- Status -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-5 col-form-label">Status:</label>
                                        <div class="col-sm-7">
                                            <select class="form-control" name="status">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4 mt-3">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                       

                       

                        

                       
                        

                        
                       

                    </div>
                </div>
            </div>
        </div>
    </div>


   
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        (function() {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function(form) {
                    form.addEventListener('submit', function(event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }

                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/notification/edit.blade.php ENDPATH**/ ?>