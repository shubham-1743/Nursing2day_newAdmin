
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Add New Schools</a></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/Schools')); ?>">+ Back Schools</a>
</div>
<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12 col-xxl-12">
            <div class="card">
                <div class="card-body">
                    <div id="smartwizard" class="form-wizard order-create">
                        <form action="" method="post" enctype="multipart/form-data">
                            
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- School Name -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">School Name:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="school_name">
                                        </div>
                                    </div>
                        
                                    <!-- Teacher Name -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Teacher Name:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="teacher_name">
                                        </div>
                                    </div>
                        
                                    <!-- Board -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Board:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="board">
                                        </div>
                                    </div>
                        
                                    <!-- Medium -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Medium:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="medium">
                                        </div>
                                    </div>
                        
                                    <!-- Phone Number -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Phone Number:</label>
                                        <div class="col-sm-9">
                                            <input type="number" class="form-control" name="phone_number">
                                        </div>
                                    </div>
                        
                                    <!-- Address -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Address:</label>
                                        <div class="col-sm-9">
                                            <textarea class="form-control" name="address" rows="2"></textarea>
                                        </div>
                                    </div>
                        
                                    <!-- Logo -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Logo:</label>
                                        <div class="col-sm-9">
                                            <input type="file" class="form-control" name="logo">
                                        </div>
                                    </div>
                        
                                    <!-- Status -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Status:</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="status">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('#smartwizard').smartWizard();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/school/create.blade.php ENDPATH**/ ?>