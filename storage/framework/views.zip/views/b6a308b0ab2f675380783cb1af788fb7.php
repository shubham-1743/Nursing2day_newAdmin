
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Edit Sliders</a></li>
        </ol>
        <a class="text-primary fs-13" href="<?php echo e(url('admin/Sliders')); ?>"><- Go Back</a>
    </div>
    <div class="container-fluid p-2">
        <!-- row -->
        <div class="row">
            <div class="col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-body">
                        <form action="" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Title -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Title:</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="title">
                                        </div>
                                    </div>
                        
                                    <!-- Slider Image -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Slider Image:</label>
                                        <div class="col-sm-8">
                                            <input type="file" class="form-control" name="slider_image">
                                        </div>
                                    </div>
                        
                                    <!-- Status -->
                                    <div class="mb-3 col-xl-4 col-md-6 row">
                                        <label class="col-sm-4 col-form-label">Status:</label>
                                        <div class="col-sm-8">
                                            <select class="form-control" name="status">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4 mt-3">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#smartwizard').smartWizard();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/sliders/edit.blade.php ENDPATH**/ ?>