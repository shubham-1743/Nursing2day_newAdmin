
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Update Boards</a></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/Boards')); ?>">+ Back Boards</a>
</div>
<div class="container-fluid p-2">
    <!-- row -->
    <div class="row">
        <div class="col-xl-12 col-xxl-12">
            <div class="card">
                <div class="card-body">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div id="smartwizard" class="form-wizard order-create">
                            <div class="row form-material">
                    
                                <!-- Board Name -->
                                <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                    <label class="col-sm-4 col-form-label">Board Name:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" name="board_name">
                                            <option value="">-- Select Board --</option>
                                            <option value="CBSE">CBSE</option>
                                            <option value="RBSE">RBSE</option>
                                        </select>
                                    </div>
                                </div>
                                
                    
                                <!-- Remark -->
                                <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                    <label class="col-sm-4 col-form-label">Remark:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="remark">
                                    </div>
                                </div>
                    
                                <!-- Status -->
                                <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                    <label class="col-sm-4 col-form-label">Status:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" name="status">
                                            <option value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                    
                            </div>
                    
                            <div class="col-4">
                                <button class="btn btn-info" type="submit">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('#smartwizard').smartWizard();
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/boards/edit.blade.php ENDPATH**/ ?>