
<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li><h5 class="bc-title">MANAGE EXPORT PARTY</h5></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(url('admin/export-parties/create')); ?>">+ Add EXPORT PARTY</a>
</div>
<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header py-3 d-sm-flex d-block">
                    <h4 class="card-title mb-2">EXPORT PARTY</h4>
                </div>
                <div class="card-header d-block pb-2">
                    <form class="row align-items-end" method="get" action="<?php echo e(route('export-parties.index')); ?>">
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">Search</label>
                            <input type="text" class="form-control" id="searchFilter">
                        </div>
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <label class="form-label">Search by party name</label>
                            <select id="party_name" name="party_name" class="form-control default-select">
                                <option value="">--select--</option>
                                <?php $__currentLoopData = $partyNameList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partyName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($partyName->party_name); ?>"><?php echo e($partyName->party_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-xl-2 col-sm-6 col-lg-4 mb-3">
                            <button id="applyFilter" class="btn btn-primary" type="submit">Apply</button>
                            <a id="resetFilter" class="btn btn-danger light ms-2" href="<?php echo e(route('export-parties.index')); ?>">Reset</a>
                        </div>
                    </form>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive active-projects style-1">
                        <table id="empoloyees-tblwrapper" class="table">
                            <thead>
                                <tr>
                                    <th>Party Code</th>
                                    <th>Party Name</th>
                                    <th>Email</th>
                                    <th>PAN No</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $exportParties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exportParty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>                            
                                        <td><?php echo e($exportParty->party_code); ?></td>
                                        <td><?php echo e($exportParty->party_name); ?></td>
                                        <td><?php echo e($exportParty->email); ?></td>
                                        <td><?php echo e($exportParty->pan_no); ?></td>
                                        <td>
                                            <?php if($exportParty->status == 1): ?>
                                                <span class="badge badge-success light border-0">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger light border-0">Deactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="badge badge-info light border-0" href="<?php echo e(url('admin/export-parties/'.$exportParty->id.'/edit')); ?>">Edit</a>
                                            <a class="badge badge-danger light border-0 delete-export-party" href="javascript:void(0);" data-id="<?php echo e($exportParty->id); ?>">Delete</a>
                                        </td>                               
                                    </tr>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($exportParties->appends(request()->query())->links()); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).on('click', '.delete-export-party', function(e) {
            e.preventDefault();
            if (!confirm('Are you sure you want to delete this export Party?')) return;

            const partyId = $(this).data('id');

            $.ajax({
                url: '/admin/export-parties/' + partyId,
                type: 'DELETE',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(response) {
                    alert('Import Party Record deleted successfully.');
                    location.reload();
                },
                error: function(xhr) {
                    alert('Failed to delete Import Party Record.');
                    console.log(xhr.responseText);
                }
            });
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brosistechnology/bamryashipping.brosistechnology.in/resources/views/admin-main/admin/party/export/index.blade.php ENDPATH**/ ?>