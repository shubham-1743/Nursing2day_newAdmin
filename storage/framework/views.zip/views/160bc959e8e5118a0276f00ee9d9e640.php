
<?php $__env->startSection('content'); ?>
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active"><a href="#">Payment</a></li>
        </ol>
        <a href="<?php echo e(url('admin/Payments')); ?>" class="text-primary"><- Go Back</a>
    </div>
    <div class="container-fluid p-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit Payment</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div id="smartwizard" class="form-wizard order-create">
                                <div class="row form-material">
                        
                                    <!-- Title -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Title:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="title">
                                        </div>
                                    </div>
                        
                                    <!-- Remark -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Remark:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="remark">
                                        </div>
                                    </div>
                        
                                    <!-- Date -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Date:</label>
                                        <div class="col-sm-9">
                                            <input type="date" class="form-control" name="date">
                                        </div>
                                    </div>
                        
                                    <!-- Wallet Amount -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Wallet Amount:</label>
                                        <div class="col-sm-9">
                                            <input type="number" step="0.01" class="form-control" name="wallet_amount">
                                        </div>
                                    </div>
                        
                                    <!-- Current Wallet Balance -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Current Balance:</label>
                                        <div class="col-sm-9">
                                            <input type="number" step="0.01" class="form-control" name="current_wallet_balance">
                                        </div>
                                    </div>
                        
                                    <!-- Updated Wallet Balance -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Updated Balance:</label>
                                        <div class="col-sm-9">
                                            <input type="number" step="0.01" class="form-control" name="updated_wallet_balance">
                                        </div>
                                    </div>
                        
                                    <!-- Recharge Date -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Recharge Date:</label>
                                        <div class="col-sm-9">
                                            <input type="date" class="form-control" name="recharge_date">
                                        </div>
                                    </div>
                        
                                    <!-- Transaction ID -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Transaction ID:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="transaction_id">
                                        </div>
                                    </div>
                        
                                    <!-- Date (again) -->
                                    <div class="mb-3 col-xl-3 col-xxl-12 col-md-6 row">
                                        <label class="col-sm-3 col-form-label">Date:</label>
                                        <div class="col-sm-9">
                                            <input type="date" class="form-control" name="another_date">
                                        </div>
                                    </div>
                        
                                </div>
                        
                                <div class="col-4">
                                    <button class="btn btn-info" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                        
                        

                        

                        

                        








                        

                    </div>
                </div>
            </div>
        </div>
    </div>


    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        (function () {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }

                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Exam-Fighter\resources\views/admin-main/admin/payment/edit.blade.php ENDPATH**/ ?>