

<?php $__env->startSection('content'); ?>
<div class="page-titles">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Edit Charge</a></li>
    </ol>
    <a class="text-primary fs-13" href="<?php echo e(route('charges.index')); ?>">+ Back Charge</a>
</div>

<div class="container-fluid p-2">
    <div class="row">
        <div class="col-xl-12 col-xxl-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('charges.update', $charge->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div id="smartwizard" class="form-wizard order-create">
                            <input type="hidden" name="company_id" value="<?php echo e($charge->company_id); ?>">
                            <div class="row form-material">

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Charge Code: <span class="text-danger">*</span></label>
                                    <input type="text" name="charge_code" class="form-control" value="<?php echo e(old('charge_code', $charge->charge_code)); ?>">
                                    <?php $__errorArgs = ['charge_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Charge Name: <span class="text-danger">*</span></label>
                                    <input type="text" name="charge_name" class="form-control" value="<?php echo e(old('charge_name', $charge->charge_name)); ?>">
                                    <?php $__errorArgs = ['charge_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Tally Ledger (Name): <span class="text-danger">*</span></label>
                                    <input type="text" name="tally_ledger_name" class="form-control" value="<?php echo e(old('tally_ledger_name', $charge->tally_ledger_name)); ?>">
                                    <?php $__errorArgs = ['tally_ledger_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Currency (I/U): <span class="text-danger">*</span></label>
                                    <select name="currency" class="form-control">
                                        <option value="INR" <?php echo e($charge->currency == 'INR' ? 'selected' : ''); ?>>INR</option>
                                        <option value="USD" <?php echo e($charge->currency == 'USD' ? 'selected' : ''); ?>>USD</option>
                                        <option value="OTH" <?php echo e($charge->currency == 'OTH' ? 'selected' : ''); ?>>Other</option>
                                    </select>
                                    <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Charge Type:</label>
                                    <select name="charge_type" class="form-control">
                                        <option value="Freight" <?php echo e($charge->charge_type == 'Freight' ? 'selected' : ''); ?>>Freight</option>
                                        <option value="Normal" <?php echo e($charge->charge_type == 'Normal' ? 'selected' : ''); ?>>Normal</option>
                                    </select>
                                    <?php $__errorArgs = ['charge_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">GST Applicable: <span class="text-danger">*</span></label>
                                    <select name="gst_applicable" class="form-control">
                                        <option value="1" <?php echo e($charge->gst_applicable == 1 ? 'selected' : ''); ?>>Yes</option>
                                        <option value="0" <?php echo e($charge->gst_applicable == 0 ? 'selected' : ''); ?>>No</option>
                                    </select>
                                    <?php $__errorArgs = ['gst_applicable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">GST %: <span class="text-danger">*</span></label>
                                    <select name="gst_percentage" class="form-control">
                                        <option value="0" <?php echo e($charge->gst_percentage == 0 ? 'selected' : ''); ?>>0%</option>
                                        <option value="5" <?php echo e($charge->gst_percentage == 5 ? 'selected' : ''); ?>>5%</option>
                                        <option value="12" <?php echo e($charge->gst_percentage == 12 ? 'selected' : ''); ?>>12%</option>
                                        <option value="18" <?php echo e($charge->gst_percentage == 18 ? 'selected' : ''); ?>>18%</option>
                                        <option value="28" <?php echo e($charge->gst_percentage == 28 ? 'selected' : ''); ?>>28%</option>
                                    </select>
                                    <?php $__errorArgs = ['gst_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Formula (Y/N):</label>
                                    <select name="has_formula" class="form-control">
                                        <option value="0" <?php echo e($charge->has_formula == 0 ? 'selected' : ''); ?>>No</option>
                                        <option value="1" <?php echo e($charge->has_formula == 1 ? 'selected' : ''); ?>>Yes</option>
                                    </select>
                                    <?php $__errorArgs = ['has_formula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Limit:</label>
                                    <input type="text" name="limit" class="form-control" value="<?php echo e(old('limit', $charge->limit)); ?>">
                                    <?php $__errorArgs = ['limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Percentage:</label>
                                    <input type="text" name="percentage" class="form-control" value="<?php echo e(old('percentage', $charge->percentage)); ?>">
                                    <?php $__errorArgs = ['percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">SAC Code: <span class="text-danger">*</span></label>
                                    <input type="text" name="sac_code" class="form-control" value="<?php echo e(old('sac_code', $charge->sac_code)); ?>">
                                    <?php $__errorArgs = ['sac_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-xl-3 col-md-6 mb-3">
                                    <label class="form-label">Status: <span class="text-danger">*</span></label>
                                    <select name="status" class="form-control">
                                        <option value="1" <?php echo e($charge->status == 1 ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e($charge->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>

                            <div class="col-4">
                                <button type="submit" class="btn btn-info">Update</button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    $('#smartwizard').smartWizard();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin-main.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brosistechnology/bamryashipping.brosistechnology.in/resources/views/admin-main/admin/charges/edit.blade.php ENDPATH**/ ?>